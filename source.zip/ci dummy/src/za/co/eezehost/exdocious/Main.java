package za.co.eezehost.exdocious;

import org.bukkit.plugin.java.JavaPlugin;

import za.co.eezehost.exdocious.help.help;

public class Main extends JavaPlugin {
	@Override
	public void onEnable() {
		new help(this);
	}

}
