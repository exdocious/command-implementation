package za.co.eezehost.exdocious.help;

import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;

import za.co.eezehost.exdocious.Main;

public class help implements CommandExecutor {
	public Main plugin;

	public help(Main plugin) {
		this.plugin = plugin;
		plugin.getCommand("cihelp").setExecutor(this);
		;
	}

	@Override
	public boolean onCommand(CommandSender sender, Command cmd, String lable, String[] args) {
		if (sender.hasPermission("cihelp")) {
			sender.sendMessage("�eAdd commands to the plugin.yml inside of the jar file");
			sender.sendMessage("�eYou can use winrar in order to access it");
			sender.sendMessage("�eDo not change name: zzzci");
			sender.sendMessage("�eIt was named to be last priority for command execution");
			sender.sendMessage("�eSeeing there are no permission dependancies these commands");
			sender.sendMessage("�eCan always be seen try /whatyouwant or /deleting");
		}
		return false;
	}
}
